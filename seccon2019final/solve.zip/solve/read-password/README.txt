How to use.

% make
% make run
% cat arm-elf.bin - | nc localhost 10000
